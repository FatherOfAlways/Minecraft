I am very happy with your support in this project.

This resource pack is developed by Digital Studio, our textures are made procedurally or photo scanned and edited, some textures are also modified by professional libraries of PBR programs

You cannot share this resource pack with others and it can only be downloaded from my patreon so you will be helping my work on this project

Do not redistribute this in anyway!

If you use this resource pack in your videos, please don't forget to give your credits by copying the following text in the video description:
__________________________________________________________________________________
Resource pack available at: https://www.patreon.com/digitalstudio
Youtube: https://www.youtube.com/channel/UCzFUw4B1o9jpcq2pWb6fI8g
__________________________________________________________________________________